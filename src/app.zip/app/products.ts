export const sampleProducts = [
    {
        "ProgramKey": 41194,
        "Program_Name": "TPRET18 Ba [Dec 28 2017  1:47PM]",
        "CompanyKey": 29822,
        "LayerKey": 115517,
        "Layer_Nbr": 1,
        "Layer_Desc": "Layer1",
        "LMF": 1
    },
    {
        "ProgramKey": 41194,
        "Program_Name": "TPRET18 Ba [Dec 28 2017  1:47PM]",
        "CompanyKey": 29822,
        "LayerKey": 115532,
        "Layer_Nbr": 2,
        "Layer_Desc": "Layer2",
        "LMF": 1
    },
    {
        "ProgramKey": 41199,
        "Program_Name": "TPRET18 Ba [Dec 28 2017  2:10PM]",
        "CompanyKey": 29822,
        "LayerKey": 115517,
        "Layer_Nbr": 1,
        "Layer_Desc": "Layer1",
        "LMF": null
    },
    {
        "ProgramKey": 41199,
        "Program_Name": "TPRET18 Ba [Dec 28 2017  2:10PM]",
        "CompanyKey": 29822,
        "LayerKey": 115532,
        "Layer_Nbr": 2,
        "Layer_Desc": "Layer2",
        "LMF": null
    },
    {
        "ProgramKey": 41200,
        "Program_Name": "TPRET18 Ba [Dec 28 2017  2:11PM]",
        "CompanyKey": 29822,
        "LayerKey": 115517,
        "Layer_Nbr": 1,
        "Layer_Desc": "Layer1",
        "LMF": null
    },
    {
        "ProgramKey": 41200,
        "Program_Name": "TPRET18 Ba [Dec 28 2017  2:11PM]",
        "CompanyKey": 29822,
        "LayerKey": 115532,
        "Layer_Nbr": 2,
        "Layer_Desc": "Layer2",
        "LMF": null
    },
    {
        "ProgramKey": 41201,
        "Program_Name": "TPRET18 Ba [Dec 28 2017  2:17PM]",
        "CompanyKey": 29822,
        "LayerKey": 115517,
        "Layer_Nbr": 1,
        "Layer_Desc": "Layer1",
        "LMF": null
    },
    {
        "ProgramKey": 41201,
        "Program_Name": "TPRET18 Ba [Dec 28 2017  2:17PM]",
        "CompanyKey": 29822,
        "LayerKey": 115532,
        "Layer_Nbr": 2,
        "Layer_Desc": "Layer2",
        "LMF": null
    },
    {
        "ProgramKey": 41202,
        "Program_Name": "TPRET18 Ba [Dec 28 2017  2:18PM]",
        "CompanyKey": 29822,
        "LayerKey": 115517,
        "Layer_Nbr": 1,
        "Layer_Desc": "Layer1",
        "LMF": null
    },
    {
        "ProgramKey": 41202,
        "Program_Name": "TPRET18 Ba [Dec 28 2017  2:18PM]",
        "CompanyKey": 29822,
        "LayerKey": 115532,
        "Layer_Nbr": 2,
        "Layer_Desc": "Layer2",
        "LMF": null
    },
    {
        "ProgramKey": 41204,
        "Program_Name": "TPRET18 Ba [Dec 28 2017  2:26PM]",
        "CompanyKey": 29822,
        "LayerKey": 115517,
        "Layer_Nbr": 1,
        "Layer_Desc": "Layer1",
        "LMF": null
    },
    {
        "ProgramKey": 41204,
        "Program_Name": "TPRET18 Ba [Dec 28 2017  2:26PM]",
        "CompanyKey": 29822,
        "LayerKey": 115532,
        "Layer_Nbr": 2,
        "Layer_Desc": "Layer2",
        "LMF": null
    },
    {
        "ProgramKey": 41208,
        "Program_Name": "Barbican B [Dec 28 2017  2:47PM]",
        "CompanyKey": 29822,
        "LayerKey": 115517,
        "Layer_Nbr": 1,
        "Layer_Desc": "Layer1",
        "LMF": null
    },
    {
        "ProgramKey": 41208,
        "Program_Name": "Barbican B [Dec 28 2017  2:47PM]",
        "CompanyKey": 29822,
        "LayerKey": 115532,
        "Layer_Nbr": 2,
        "Layer_Desc": "Layer2",
        "LMF": null
    },
    {
        "ProgramKey": 41211,
        "Program_Name": "BESIM [Dec 28 2017  2:47PM]",
        "CompanyKey": 29822,
        "LayerKey": 115517,
        "Layer_Nbr": 1,
        "Layer_Desc": "Layer1",
        "LMF": null
    },
    {
        "ProgramKey": 41211,
        "Program_Name": "BESIM [Dec 28 2017  2:47PM]",
        "CompanyKey": 29822,
        "LayerKey": 115532,
        "Layer_Nbr": 2,
        "Layer_Desc": "Layer2",
        "LMF": null
    }
];