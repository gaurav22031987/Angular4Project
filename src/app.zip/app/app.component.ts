import { Component, OnInit, ViewChild, Renderer2 } from '@angular/core';
import { programCurve } from './programCurve';
import { FormGroup, Validators, FormBuilder } from "@angular/forms";
import { AddEvent, EditEvent, GridComponent } from '@progress/kendo-angular-grid';


const hasClass = (el, className) => new RegExp(className).test(el.className);

const isChildOf = (el, className) => {
    while (el && el.parentElement) {
        if (hasClass(el.parentElement, className)) {
            return true;
        }
        el = el.parentElement;
    }
    return false;
};


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app work/s!';
  uniqueIds: any[] = [];
  public gridData: any[] = [];
  @ViewChild(GridComponent) private grid: GridComponent;
  public formGroup: FormGroup;
  private editedRowIndex: number;
  constructor(private formBuilder: FormBuilder, private renderer: Renderer2) {

  }
  ngOnInit() {

    this.gridData = programCurve;
    this.renderer.listen(
      'document',
      'click',
      ({ target }) => {
        if (!isChildOf(target, 'k-grid-content') && !isChildOf(target, 'k-grid-toolbar')) {
          this.saveRow();
        }
      });


    // sampleProducts.filter((x: any) => {
    //   if (!this.uniqueIds.find(id => id === x.Layer_Nbr))
    //     this.uniqueIds.push(x.Layer_Nbr);
    // });

    // this.uniqueIds.forEach(id => {
    //   this.gridData.push({ 'Layer_Nbr': id });
    //   sampleProducts.filter((x: any) => x.Layer_Nbr === id).forEach(item => {
    //     this.gridData[this.gridData.length - 1][this.replace(item.Program_Name)] = item.LMF;
    //   })
    // });
  }
  public editHandler({ sender, rowIndex, dataItem }: EditEvent): void {
    this.saveRow();
    this.formGroup = this.createFormGroup(dataItem);
    this.editedRowIndex = rowIndex;
    sender.editRow(rowIndex, this.formGroup);
  }



  public editClick({ dataItem, rowIndex }: any): void {
    this.editHandler({
      dataItem: dataItem,
      rowIndex: rowIndex,
      sender: this.grid,
      isNew: false
    });
  }

  public createFormGroup(dataItem: any): FormGroup {
    const columns: any = {};
    Object.keys(dataItem).forEach((key: any) => {
      if (key !== "Layer_Nbr")
        columns[this.replace(key)] = dataItem[key];
    });
    return this.formBuilder.group(columns);
  }
  private closeEditor(grid: GridComponent, rowIndex: number = this.editedRowIndex): void {
    grid.closeRow(rowIndex);
    this.editedRowIndex = undefined;
    this.formGroup = undefined;
  }

  private saveRow(): void {
    this.closeEditor(this.grid);
  }
  replace(str: string): string {

    return str.replace(/[' ']/g, '_').replace(/[\[]/g, 'SS').replace(/[\]]/g, 'EE').replace(/[\:]/g, 'CC').replace("(", 'RR').replace(")", 'MM');
  }

  getHeaderTitle(str: string): string {

    return str.replace(/[_]/g, ' ').replace(/SS/g, '[').replace(/EE/g, ']').replace(/CC/g, ':');
  }
  getColumns() {
    if (this.gridData) {
      const columns = Object.keys(this.gridData[0])
      columns.splice(0, 1);
      return columns;
    }
  }
}


export class ProgramClass {
  layer_Num: number;
  programInfo: { programKey: string, programName: string };
}