export const programCurve = [
    {
        "Layer_Nbr": "1",
        "Barbican B [Dec 28 2017  2:47PM]": null,
        "BESIM [Dec 28 2017  2:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  1:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:10PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:11PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:17PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:18PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:26PM]": null
    },
    {
        "Layer_Nbr": "2",
        "Barbican B [Dec 28 2017  2:47PM]": null,
        "BESIM [Dec 28 2017  2:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  1:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:10PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:11PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:17PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:18PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:26PM]": null
    },
    {
        "Layer_Nbr": "3",
        "Barbican B [Dec 28 2017  2:47PM]": null,
        "BESIM [Dec 28 2017  2:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  1:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:10PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:11PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:17PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:18PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:26PM]": null
    },
    {
        "Layer_Nbr": "4",
        "Barbican B [Dec 28 2017  2:47PM]": "1",
        "BESIM [Dec 28 2017  2:47PM]": "1",
        "TPRET18 Ba [Dec 28 2017  1:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:10PM]": "1",
        "TPRET18 Ba [Dec 28 2017  2:11PM]": "1",
        "TPRET18 Ba [Dec 28 2017  2:17PM]": "1",
        "TPRET18 Ba [Dec 28 2017  2:18PM]": "1",
        "TPRET18 Ba [Dec 28 2017  2:26PM]": null
    },
    {
        "Layer_Nbr": "5",
        "Barbican B [Dec 28 2017  2:47PM]": null,
        "BESIM [Dec 28 2017  2:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  1:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:10PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:11PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:17PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:18PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:26PM]": null
    },
    {
        "Layer_Nbr": "6",
        "Barbican B [Dec 28 2017  2:47PM]": null,
        "BESIM [Dec 28 2017  2:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  1:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:10PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:11PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:17PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:18PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:26PM]": null
    },
    {
        "Layer_Nbr": "7",
        "Barbican B [Dec 28 2017  2:47PM]": "1",
        "BESIM [Dec 28 2017  2:47PM]": "1",
        "TPRET18 Ba [Dec 28 2017  1:47PM]": "1",
        "TPRET18 Ba [Dec 28 2017  2:10PM]": "1",
        "TPRET18 Ba [Dec 28 2017  2:11PM]": "1",
        "TPRET18 Ba [Dec 28 2017  2:17PM]": "1",
        "TPRET18 Ba [Dec 28 2017  2:18PM]": "1",
        "TPRET18 Ba [Dec 28 2017  2:26PM]": "1"
    },
    {
        "Layer_Nbr": "8",
        "Barbican B [Dec 28 2017  2:47PM]": null,
        "BESIM [Dec 28 2017  2:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  1:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:10PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:11PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:17PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:18PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:26PM]": null
    },
    {
        "Layer_Nbr": "9",
        "Barbican B [Dec 28 2017  2:47PM]": null,
        "BESIM [Dec 28 2017  2:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  1:47PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:10PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:11PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:17PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:18PM]": null,
        "TPRET18 Ba [Dec 28 2017  2:26PM]": null
    }
]